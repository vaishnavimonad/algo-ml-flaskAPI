import pickle
import numpy as np
import pandas as pd
from time import sleep
from datetime import datetime
import logging
import configparser
config = configparser.ConfigParser()
config.read('config.ini')
logging.basicConfig(filename=config['DATA']['LOG_PATH'], filemode='a',level=logging.INFO, format='%(name)s - %(levelname)s - %(message)s')

class predict_value:    
    def __init__(self):
        try:
            self.model1_path = config['DATA']['MODEL1']
            self.model1 = {'af2P_minPLowBfMaxPHigh_date_index':
                         pickle.load(open('{0}/af2P_minPLowBfMaxPHigh_date_index_model.sav'.format(self.model1_path),'rb')),
                        'af2P_minPLowBfMaxPHigh_pLow_index':
                         pickle.load(open('{0}/af2P_minPLowBfMaxPHigh_pLow_index_model.sav'.format(self.model1_path),'rb')),
                        'af2P_minPAvgBfMaxPAvg_date_index':
                         pickle.load(open('{0}/af2P_minPAvgBfMaxPAvg_date_index_model.sav'.format(self.model1_path),'rb')),
                        'af2P_minPAvgBfMaxPAvg_pAvg_index':
                         pickle.load(open('{0}/af2P_minPAvgBfMaxPAvg_pAvg_index_model.sav'.format(self.model1_path),'rb')),
                        'af2P_maxPHigh_date_index':
                         pickle.load(open('{0}/af2P_maxPHigh_date_index_model.sav'.format(self.model1_path),'rb')),
                        'af2P_maxPHigh_pHigh_index':
                         pickle.load(open('{0}/af2P_maxPHigh_pHigh_index_model.sav'.format(self.model1_path),'rb')),
                        'af2P_maxPAvg_date_index':
                         pickle.load(open('{0}/af2P_maxPAvg_date_index_model.sav'.format(self.model1_path),'rb')),
                        'af2P_maxPAvg_pAvg_indexPerf':
                         pickle.load(open('{0}/af2P_maxPAvg_pAvg_indexPerf_model.sav'.format(self.model1_path),'rb')),
                        'af2P_priceInPerf_pAvgxVol_inM':
                         pickle.load(open('{0}/af2P_priceInPerf_pAvgxVol_inM_model.sav'.format(self.model1_path),'rb')),
                        'cl_perf_pAvg_volIsSuff':
                         pickle.load(open('{0}/cl_perf_pAvg_volIsSuff_model.sav'.format(self.model1_path),'rb')),
                        'af2P_perfEnd_date_index':
                         pickle.load(open('{0}/af2P_perfEnd_date_index_model.sav'.format(self.model1_path),'rb'))}

            self.model2_path = config['DATA']['MODEL2']
            self.model2 = {'af2P_maxPAvg_pAvg_indexPerf':
                        pickle.load(open('{0}/af2P_maxPAvg_pAvg_indexPerf_pmae_model.sav'.format(self.model2_path),'rb')),
                       'af2P_maxPHigh_pHigh_index':
                        pickle.load(open('{0}/af2P_maxPHigh_pHigh_index_pmae_model.sav'.format(self.model2_path),'rb')),
                        'af2P_minPAvgBfMaxPAvg_pAvg_index':
                         pickle.load(open('{0}/af2P_minPAvgBfMaxPAvg_pAvg_index_nmae_model.sav'.format(self.model2_path),'rb')),
                        'af2P_minPLowBfMaxPHigh_pLow_index':
                         pickle.load(open('{0}/af2P_minPLowBfMaxPHigh_pLow_index_nmae_model.sav'.format(self.model2_path),'rb'))}


        except Exception as ex:
            logging.info("class:predict_value init(): {}".format(ex))
                          
    
    def predict(self, X_test, modelname, out_path):
        start = datetime.now()
        y_pred = dict()
                
        try:
            #preprocessing
            X_test['1STo2S_1VP_volOverOther_pc'].replace([np.inf, -np.inf], np.nan, inplace=True)
            X_test.fillna(X_test.mean(), inplace=True)

            #loading scaler which was fit using X_train and scaling input 
            scaler = pickle.load(open('scaler.sav', 'rb'))  
            X_test_scaled = scaler.transform(X_test) 

            #calling predict()
            if modelname == self.model1_path:
                for model in self.model1.keys():
                    y_pred[model] = self.model1[model].predict(X_test_scaled).tolist()
            if modelname == self.model2_path:
                for model in self.model2.keys():
                    y_pred[model] = self.model2[model].predict(X_test_scaled).tolist()

            #saving predictions
            y_pred_df = pd.DataFrame.from_dict(y_pred)
            y_pred_df.index = X_test.index
            y_pred_df.to_csv(out_path)

            time_taken = (datetime.now() - start)
            logging.info("time taken to execute predict function : {}".format(time_taken))
            
        except Exception as ex:
            status = 500
            logging.info("predict(): {0}".format(ex))
        
       
     
