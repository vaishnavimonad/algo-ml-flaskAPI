import pandas as pd
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split

import pickle

dataset = pd.read_excel (r'data/data.xlsx',sheet_name='Data')


X = dataset[:,0:7]
Y = dataset[:,7]




X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=1)

model = XGBRegressor()
model.fit(X_train, y_train)
filename = 'model/finalized_model.sav'
pickle.dump(model, open(filename, 'wb'))

